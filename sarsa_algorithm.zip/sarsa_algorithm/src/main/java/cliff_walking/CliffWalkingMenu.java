package cliff_walking;


import cliff_walking.Main.CliffWalking;
import cliff_walking.Main.Environment;
import cliff_walking.Main.EnvironmentTypes;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class CliffWalkingMenu {

    public CliffWalkingMenu(){
        init();
    }

    public void init() {
        Stage primaryStage = new Stage();

        // SnakeMenu pane
        BorderPane mainPane = new BorderPane();


        // Header pane
        VBox headerVbox = new VBox();

        Text headline = new Text("Cliff Walking");
        headline.setFont(new Font("Arial Black", 36));
        headline.setFill(Color.WHITE);

        headerVbox.setAlignment(Pos.CENTER);
        headerVbox.setBackground(new Background(new BackgroundFill(Color.DARKSLATEGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        headerVbox.getChildren().add(headline);

        Button createMapEditorButton = new Button("Create own map");
        createMapEditorButton.setAlignment(Pos.CENTER_RIGHT);
        createMapEditorButton.setOnAction(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("Not implemented yet");
            alert.setContentText("Sorry, this feature will be hopefully implemented in the near future.");
            alert.show();
        });
        headerVbox.getChildren().add(createMapEditorButton);


        // Content pane
        TilePane contentTilePane = new TilePane();
        contentTilePane.setHgap(0.0);
        contentTilePane.setVgap(0.0);
        contentTilePane.setPadding(new Insets(20,20,20,20));

        EnvironmentTypes.init();

        for(Environment env : EnvironmentTypes.environments){
            Canvas map = new Canvas(env.getWidth()*env.getRectSmallSize(),env.getHeight()*env.getRectSmallSize());
            map.getStyleClass().add("canvas");

            GraphicsContext gc = map.getGraphicsContext2D();

            env.renderGrid(gc, true);

            Pane pane = new Pane();
            pane.setPrefSize(200,200);
            pane.setBorder(new Border(new BorderStroke(Color.BLACK,
                    BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(3))));
            pane.getChildren().add(map);
            pane.setOnMouseClicked(event -> {
                pane.setScaleZ(0.1);
            });

            map.setOnMouseClicked(e -> {
                new CliffWalking(env);
            });
//            pane.hoverProperty().addListener((observable,oldValue,show) -> {
//                if(show){
//                    pane.setScaleZ(1.5);
//                } else {
//                    pane.setScaleZ(1);
//                }
//            });

            contentTilePane.getChildren().add(map);
        }

        mainPane.setTop(headerVbox);
        mainPane.setCenter(contentTilePane);

        Scene scene = new Scene(mainPane,1000,500);
        scene.getStylesheets().add("css/CliffWalkingMenuStyles.css");

        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
//                Platform.exit();
//                System.exit(0);
                mainPane.getChildren().clear();
            }
        });
        primaryStage.setScene(scene);
        primaryStage.setTitle("Cliff Walking menu");
        primaryStage.show();
    }
}
