package cliff_walking.Main;

import TD_Algorithms.utils.Constants;
import cliff_walking.Main.patterns.CliffWalkingStrategy;
import cliff_walking.Main.utils.Agent;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.util.HashMap;
import java.util.Map;

// todo Add TD algorithms types
enum CliffWalkingTDAlgorithmsTypes {
    SARSA("SARSA");

    private String algorithmName;

    CliffWalkingTDAlgorithmsTypes(String algorithmName) {
        this.algorithmName = algorithmName;
    }

    public String getAlgorithmName() {
        return algorithmName;
    }
}


/**
 * Cliff walking handling
 */
public class CliffWalking {

    public static Integer epochsCount = 0;

    public static Integer accelerateEpochsCount = 0;

    public static boolean normalSpeed = true;


    // Performance
    public static volatile boolean threadShutdown = false;
    public static volatile boolean threadStarted = false;
    public Thread thread;

    // Environment set-up
    public Environment cliffEnvironment;
    public Agent agent;


    // Layout
    public static Label epochsLabel = new Label("Iterations: " + epochsCount.toString());

    public static Label goalReachedLabel = new Label("");

    private String[] algorithmOptions = {CliffWalkingTDAlgorithmsTypes.SARSA.getAlgorithmName()};

    private Slider epsilonValueLevel;
    private Slider alphaValueLevel;
    private Slider gammaValueLevel;
    private TextField normalFieldValueInput;
    private TextField cliffFieldValueInput;
    private TextField goalFieldValueInput;
    private TextField edgeFieldValueInput;


    // todo Add algorithm to strategy pattern
    // Strategy pattern
    private Map<CliffWalkingTDAlgorithmsTypes, CliffWalkingStrategy> cliffWalkingStrategies = new HashMap<CliffWalkingTDAlgorithmsTypes, CliffWalkingStrategy>() {{

       put(CliffWalkingTDAlgorithmsTypes.SARSA, new CliffWalkingWithSarsa());

    }};
    // todo Set default algorithm strategy
    private CliffWalkingStrategy cliffWalkingStrategy = this.cliffWalkingStrategies.get(CliffWalkingTDAlgorithmsTypes.SARSA);



    public CliffWalking() {
    }

    public CliffWalking(Environment environment){
        init(environment);
    }

    public void init(Environment env) {
        Stage stage = new Stage();

        // Canvas
        Canvas canvas;

        // Create cliff environment
        if(env != null){
            cliffEnvironment = env;
            canvas = env.getCanvas();

        } else {
            cliffEnvironment = new Environment();
            canvas = new Canvas(600, 255);
        }

        // Init Graphic context
        GraphicsContext gc = canvas.getGraphicsContext2D();

//        controller = new Controller();

        cliffEnvironment.renderGrid(gc, false);

        // Create player
        agent = new Agent(cliffEnvironment.getStartX(), cliffEnvironment.getStartY(), cliffEnvironment.getRectSize(), cliffEnvironment.getGridPositions());


        // Canvas group
        Group group = new Group();
//        TranslateTransition translateTransition = controller.createTranslateTransition(agent.getRectangle());

        group.getChildren().add(canvas);
        group.getChildren().add(agent.getRectangle());


        // Menu Layout
        BorderPane mainPane = new BorderPane();
        mainPane.setTop(this.createHeaderLayout());
        mainPane.setRight(createRightSettingLayout());
        mainPane.setCenter(group);


        Scene scene = new Scene(mainPane);


        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
//                Platform.exit();
//                System.exit(0);
                threadInterrupt();
            }
        });
        stage.setScene(scene);
        stage.setTitle("Cliff walking");
        stage.show();


        System.out.println("Cliff walking initialized");

//        // Start algorithm
        this.startThread();
    }


    /**
     * Utils functions
     */
    private void startThread() {
        this.thread = new Thread(() ->
        {
//            this.cliffWalkingStrategy.play(this.thread);
            // Strategy algorithm choose and execute
            this.cliffWalkingStrategy.chooseTDAlgorithmAndExecute(this.thread, this.cliffEnvironment, this.agent);
        });
    }

    private void reset() {
        epochsCount = 0;
        accelerateEpochsCount = 0;
        normalSpeed = true;
        threadShutdown = false;
        threadStarted = false;
        epochsLabel.setText("Iterations: " + epochsCount.toString());
        goalReachedLabel.setText("");
        this.agent.setPosition(this.cliffEnvironment.getStartX(), this.cliffEnvironment.getStartY());

        this.epsilonValueLevel.setValue(Constants.epsilon);
        this.alphaValueLevel.setValue(Constants.alpha);
        this.gammaValueLevel.setValue(Constants.gamma);
        this.normalFieldValueInput.setText(Double.toString(Constants.normalFieldValue));
        this.cliffFieldValueInput.setText(Double.toString(Constants.cliffFieldValue));
        this.edgeFieldValueInput.setText(Double.toString(Constants.edgeFieldValue));
        this.goalFieldValueInput.setText(Double.toString(Constants.goalFieldValue));
    }

    private void threadInterrupt() {
        threadShutdown = true;
        try {
            thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        thread.interrupt();
            Constants.setToDefaultValuesForSarsa();
        reset();

        System.out.println("Cliff walking ended");
    }

    // todo Add algorithm switch strategy
    private void switchAlgorithms(String value) {
        switch (CliffWalkingTDAlgorithmsTypes.valueOf(value)) {
            case SARSA:

                threadInterrupt();
                this.cliffWalkingStrategy = this.cliffWalkingStrategies.get(CliffWalkingTDAlgorithmsTypes.SARSA);
                this.startThread();
                System.out.println("Strategy switched to SARSA");

                break;
        }
    }


    /**
     * Create layout functions
     */
    public HBox createHeaderLayout() {

        // Header Layout
        HBox headerHBox = new HBox();
        headerHBox.setPadding(new Insets(15, 12, 15, 12));
        headerHBox.setSpacing(10);
        headerHBox.setStyle("-fx-background-color: #336699;");

        Button buttonCurrent = new Button("Accelerate");
        buttonCurrent.setPrefSize(100, 20);
        buttonCurrent.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                normalSpeed = false;
            }
        });

        epochsLabel.setStyle("-fx-font-size: 15pt;\n" +
                "    -fx-font-family: \"Segoe UI Semibold\";");
        goalReachedLabel.setStyle("-fx-font-size: 15pt;\n" +
                "    -fx-font-family: \"Segoe UI Semibold\";");
        goalReachedLabel.setTextFill(Color.GREEN);
//        bestMaxGenerationsLabel.setText("Best Max: " + bestMaxGenerations);

        headerHBox.getChildren().addAll(buttonCurrent, epochsLabel, goalReachedLabel);

        return headerHBox;
    }


    public GridPane createRightSettingLayout() {

        GridPane settingGridPane = new GridPane();
        settingGridPane.setPrefWidth(180);
        settingGridPane.setPadding(new Insets(10, 10, 10, 10));
        settingGridPane.setVgap(5);
        settingGridPane.setHgap(1);
//        settingGridPane.setGridLinesVisible(true);

        Text algorithmOptionLabel = new Text("Choose algorithm:");
        ComboBox algorithmOptionComboBox = new ComboBox(FXCollections.observableArrayList(algorithmOptions));
        algorithmOptionComboBox.getSelectionModel().selectFirst();
        algorithmOptionComboBox.setMaxWidth(Double.MAX_VALUE);

        algorithmOptionComboBox.valueProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {

                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Change Temporal difference algorithm");
                alert.setHeaderText("Do you really want to change algorithm?");
                alert.setContentText("All learning data will be lost");
                alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);
                alert.showAndWait().ifPresent(type -> {
                    if (type == ButtonType.YES) {
                        System.out.println("YES " + newValue);
                        algorithmOptionComboBox.setValue(newValue);
                        switchAlgorithms(newValue);
                    } else if (type == ButtonType.NO) {
                        Platform.runLater(() -> algorithmOptionComboBox.setValue(oldValue));
                        System.out.println("NO " + oldValue);
                    }
                });
            }
        });


        Text normalFieldValueLabel = new Text("Normal field reward:");
        normalFieldValueInput = new TextField();
        normalFieldValueInput.setText(Double.toString(Constants.normalFieldValue));

        Button normalFieldValueButton = new Button("Apply");
        normalFieldValueButton.setMinWidth(50);
        normalFieldValueButton.setOnAction(event -> {
            Constants.normalFieldValue = Double.valueOf(normalFieldValueInput.textProperty().getValue());
            normalFieldValueInput.setText(String.valueOf(Constants.normalFieldValue));
        });


        Text cliffFieldValueLabel = new Text("Cliff field reward:");
        cliffFieldValueInput = new TextField();
        cliffFieldValueInput.setText(Double.toString(Constants.cliffFieldValue));

        Button cliffFieldValueButton = new Button("Apply");
        cliffFieldValueButton.setMinWidth(50);
        cliffFieldValueButton.setOnAction(event -> {
            Constants.cliffFieldValue = Double.valueOf(cliffFieldValueInput.textProperty().getValue());
            cliffFieldValueInput.setText(String.valueOf(Constants.cliffFieldValue));
        });


        Text goalFieldValueLabel = new Text("Goal field reward:");
        goalFieldValueInput = new TextField();
        goalFieldValueInput.setText(Double.toString(Constants.goalFieldValue));

        Button goalFieldValueButton = new Button("Apply");
        goalFieldValueButton.setMinWidth(50);
        goalFieldValueButton.setOnAction(event -> {
            Constants.goalFieldValue = Double.valueOf(goalFieldValueInput.textProperty().getValue());
            goalFieldValueInput.setText(String.valueOf(Constants.goalFieldValue));
        });


        Text edgeFieldValueLabel = new Text("Edge field reward:");
        edgeFieldValueInput = new TextField();
        edgeFieldValueInput.setText(Double.toString(Constants.edgeFieldValue));

        Button edgeFieldValueButton = new Button("Apply");
        edgeFieldValueButton.setMinWidth(50);
        edgeFieldValueButton.setOnAction(event -> {
            Constants.edgeFieldValue = Double.valueOf(edgeFieldValueInput.textProperty().getValue());
            edgeFieldValueInput.setText(String.valueOf(Constants.edgeFieldValue));
        });


        Text epsilonValue = new Text("Epsilon:");
        epsilonValueLevel = new Slider(0, 1, Constants.epsilon);
        final Label epsilonValueLabel = new Label(Double.toString(epsilonValueLevel.getValue()));
        epsilonValueLabel.setMaxWidth(Double.MAX_VALUE);

        epsilonValueLevel.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                Constants.epsilon = newValue.doubleValue();
                epsilonValueLabel.setText(String.format("%.2f", Constants.epsilon));
            }
        });

        Text alphaValue = new Text("Alpha:");
        alphaValueLevel = new Slider(0, 1, Constants.alpha);
        final Label alphaValueLabel = new Label(Double.toString(alphaValueLevel.getValue()));
        alphaValueLabel.setMaxWidth(Double.MAX_VALUE);

        alphaValueLevel.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                Constants.alpha = newValue.doubleValue();
                alphaValueLabel.setText(String.format("%.2f", Constants.alpha));
            }
        });


        Text gammaValue = new Text("Gamma:");
        gammaValueLevel = new Slider(0, 1, Constants.gamma);
        final Label gammaValueLabel = new Label(Double.toString(gammaValueLevel.getValue()));
        gammaValueLabel.setMaxWidth(Double.MAX_VALUE);

        gammaValueLevel.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                Constants.gamma = newValue.doubleValue();
                gammaValueLabel.setText(String.format("%.2f", Constants.gamma));
            }
        });


        Button stopButton = new Button("Stop");
        stopButton.setOnAction(event -> {
            this.threadShutdown = true;

        });

        Button startButton = new Button("Start");
        startButton.setOnAction(event -> {
            // Start algorithm

            if(!threadStarted) {
                threadStarted = true;
                this.threadShutdown = false;
                this.thread.start();
            } else {
                this.threadShutdown = false;
            }
        });


        HBox buttonsHBox = new HBox();
        buttonsHBox.setSpacing(10);
        stopButton.setMaxWidth(Double.MAX_VALUE);
        startButton.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(stopButton,Priority.ALWAYS);
        HBox.setHgrow(startButton,Priority.ALWAYS);

        buttonsHBox.getChildren().addAll(stopButton,startButton);


        GridPane.setHgrow(normalFieldValueButton,Priority.ALWAYS);
        GridPane.setVgrow(normalFieldValueButton,Priority.ALWAYS);

        settingGridPane.add(algorithmOptionLabel, 0,0);
        settingGridPane.add(algorithmOptionComboBox,0,1,2,1);

        settingGridPane.add(normalFieldValueLabel, 0,2);
        settingGridPane.add(normalFieldValueInput, 0,3);
        settingGridPane.add(normalFieldValueButton,1,3);
        settingGridPane.add(cliffFieldValueLabel, 0,4);
        settingGridPane.add(cliffFieldValueInput, 0,5);
        settingGridPane.add(cliffFieldValueButton, 1,5);
        settingGridPane.add(goalFieldValueLabel, 0,6);
        settingGridPane.add(goalFieldValueInput, 0,7);
        settingGridPane.add(goalFieldValueButton, 1,7);
        settingGridPane.add(edgeFieldValueLabel, 0,8);
        settingGridPane.add(edgeFieldValueInput, 0,9);
        settingGridPane.add(edgeFieldValueButton, 1,9);

        settingGridPane.add(epsilonValue,0,10);
        settingGridPane.add(epsilonValueLevel,0,11);
        settingGridPane.add(epsilonValueLabel,1,11,2,1);

        settingGridPane.add(alphaValue,0,12);
        settingGridPane.add(alphaValueLevel,0,13);
        settingGridPane.add(alphaValueLabel,1,13);

        settingGridPane.add(gammaValue,0,14);
        settingGridPane.add(gammaValueLevel,0,15);
        settingGridPane.add(gammaValueLabel,1,15);

        settingGridPane.add(buttonsHBox,0,16,2,1);


        return settingGridPane;
    }
}
