package cliff_walking.Main;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.List;


public class Environment {

    private Canvas canvas;

    private int canvasWidth = 600;

    private int canvasHeight = 255;

    private int width = 14;

    private int height = 6;

    private int span = 0;

    private int rectSize = 40;

    private int rectSmallSize = 15;

    private int startX = 4;
    private int startY = 1;

    private String [][] grid = {
            {"-1","-1","-1","-1","-1","-1","-1","-1","-1","-1","-1","-1","-1","-1"},
            {"-1","0","0","0","0","0","0","0","0","0","0","0","0","-1"},
            {"-1","0","0","0","0","0","0","0","0","0","0","0","0","-1"},
            {"-1","0","0","0","0","0","0","0","0","0","0","0","0","-1"},
            {"-1","0","*","*","*","*","*","*","*","*","*","*","G","-1"},
            {"-1","-1","-1","-1","-1","-1","-1","-1","-1","-1","-1","-1","-1","-1"},
    };

    private List<Integer>[][] gridPositions = new ArrayList[height][width];


    public Environment() {
        this.canvas = new Canvas(this.canvasWidth,this.canvasHeight);
    }

    public Environment(int canvasWidth, int canvasHeight, int width, int height, int span) {
        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;
        this.canvas = new Canvas(this.canvasWidth,this.canvasHeight);
        this.width = width;
        this.height = height;
        this.span = span;
        this.gridPositions = new ArrayList[height][width];
    }

    public Environment(int canvasWidth, int canvasHeight, int width, int height, int span, String[][] grid) {
        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;
        this.canvas = new Canvas(this.canvasWidth,this.canvasHeight);
        this.width = width;
        this.height = height;
        this.span = span;
        this.grid = grid;
        this.gridPositions = new ArrayList[height][width];
    }

    public Environment(int canvasWidth, int canvasHeight, int width, int height, int span, int rectSize, String[][] grid) {
        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;
        this.canvas = new Canvas(this.canvasWidth,this.canvasHeight);
        this.width = width;
        this.height = height;
        this.span = span;
        this.rectSize = rectSize;
        this.grid = grid;
        this.gridPositions = new ArrayList[height][width];
    }

    public Environment(int width, int height, int span, int rectSize, String[][] grid) {
        this.canvasWidth = width*rectSize+10;
        this.canvasHeight = height*rectSize+10;
        this.canvas = new Canvas(this.canvasWidth,this.canvasHeight);
        this.width = width;
        this.height = height;
        this.span = span;
        this.rectSize = rectSize;
        this.grid = grid;
        this.gridPositions = new ArrayList[height][width];
    }

    public Environment(int canvasWidth, int canvasHeight, int width, int height, int span, int rectSize) {
        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;
        this.canvas = new Canvas(this.canvasWidth,this.canvasHeight);
        this.width = width;
        this.height = height;
        this.span = span;
        this.rectSize = rectSize;
        this.gridPositions = new ArrayList[height][width];
    }

    public void renderGrid(GraphicsContext gc, boolean miniature){

        Image soilImage = new Image("ReinforcementLearningAssets/CliffWalking/soil.jpg");
        Image wallImage = new Image("ReinforcementLearningAssets/CliffWalking/wall3.jpg");
        Image rockImage = new Image("ReinforcementLearningAssets/CliffWalking/rock.jpg");
        Image waterImage = new Image("ReinforcementLearningAssets/CliffWalking/water.jpg");
        Image cliffImage = new Image("ReinforcementLearningAssets/CliffWalking/cliff.jpg");
        Image startImage = new Image("ReinforcementLearningAssets/CliffWalking/start.jpg");
        Image finishImage = new Image("ReinforcementLearningAssets/CliffWalking/finish2.jpg");


//        this.grid[startX][startY] = "S";
        Rectangle rect;

        List<Integer> pos;

        for(int i = 0; i < height; i++){
            for(int j = 0; j < width; j++){

                if(miniature){
                    rect = new Rectangle();
                    rect.setWidth(this.rectSmallSize);
                    rect.setHeight(this.rectSmallSize);

                    rect.setX(j * (this.rectSmallSize+this.span));
                    rect.setY(i * (this.rectSmallSize+this.span));
                } else {
                    rect = new Rectangle();
                    rect.setWidth(this.rectSize);
                    rect.setHeight(this.rectSize);

                    rect.setX(j * (this.rectSize + this.span));
                    rect.setY(i * (this.rectSize + this.span));
                }

                pos = new ArrayList<>();
                pos.add((int)rect.getX());
                pos.add((int)rect.getY());

                gridPositions[i][j] = pos;

//                gc.setFill(Color.GREY);
                gc.setFill(new ImagePattern(soilImage));

                if(this.grid[i][j].equals("-1")){
//                    gc.setFill(Color.BLUEVIOLET);
                    gc.setFill(new ImagePattern(waterImage));
                }

                if(this.grid[i][j].equals("*")){
//                    gc.setFill(Color.RED);
                    gc.setFill(new ImagePattern(cliffImage));
                }

                if(this.grid[i][j].equals("G")){
//                    gc.setFill(Color.GOLD);
                    gc.setFill(new ImagePattern(finishImage));
                }

                if(this.grid[i][j].equals("S")){
                    gc.setFill(new ImagePattern(soilImage));
                    gc.setFill(new ImagePattern(startImage));
                    this.startX = i;
                    this.startY = j;
                }

                gc.fillRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());

//                gc.drawImage(soilImage, this.rectSize, this.rectSize);

//                System.out.print(this.grid[i][j] + " ");
//                System.out.print(this.gridPositions[i][j].toString() + " ");
            }
//            System.out.println("Cliff walking environment rendered");
        }
    }

    public Canvas getCanvas() {
        return canvas;
    }

    public void setCanvas(Canvas canvas) {
        this.canvas = canvas;
    }

    public int getCanvasWidth() {
        return canvasWidth;
    }

    public void setCanvasWidth(int canvasWidth) {
        this.canvasWidth = canvasWidth;
    }

    public int getCanvasHeight() {
        return canvasHeight;
    }

    public void setCanvasHeight(int canvasHeight) {
        this.canvasHeight = canvasHeight;
    }

    public int getRectSmallSize() {
        return rectSmallSize;
    }

    public void setRectSmallSize(int rectSmallSize) {
        this.rectSmallSize = rectSmallSize;
    }

    public String getValueOnIndex(int x, int y){
        return this.grid[x][y];
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getSpan() {
        return span;
    }

    public void setSpan(int span) {
        this.span = span;
    }

    public int getRectSize() {
        return rectSize;
    }

    public void setRectSize(int rectSize) {
        this.rectSize = rectSize;
    }

    public int getStartX() {
        return startX;
    }

    public void setStartX(int startX) {
        this.startX = startX;
    }

    public int getStartY() {
        return startY;
    }

    public void setStartY(int startY) {
        this.startY = startY;
    }

    public String[][] getGrid() {
        return grid;
    }

    public void setGrid(String[][] grid) {
        this.grid = grid;
    }

    public List<Integer>[][] getGridPositions() {
        return gridPositions;
    }

    public void setGridPositions(List<Integer>[][] gridPositions) {
        this.gridPositions = gridPositions;
    }
}
