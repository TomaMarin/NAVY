package cliff_walking.Main;

import TD_Algorithms.algorithms.sarsa.SarsaAgent;
import TD_Algorithms.models.State;
import TD_Algorithms.utils.Constants;
import cliff_walking.Main.patterns.CliffWalkingStrategy;
import cliff_walking.Main.utils.Agent;
import javafx.application.Platform;

import static cliff_walking.Main.CliffWalking.accelerateEpochsCount;
import static cliff_walking.Main.CliffWalking.epochsCount;
import static cliff_walking.Main.CliffWalking.epochsLabel;
import static cliff_walking.Main.CliffWalking.goalReachedLabel;
import static cliff_walking.Main.CliffWalking.normalSpeed;


public class CliffWalkingWithSarsa implements CliffWalkingStrategy {

    public Controller controller;
    public Environment cliffEnvironment;
    public Agent agent;
    public SarsaAgent sarsaAgent;

    public CliffWalkingWithSarsa() {

    }

    @Override
    public void chooseTDAlgorithmAndExecute(Thread thread, Environment environment, Agent agent) {
        this.cliffEnvironment = environment;
        this.agent = agent;

        this.init();

        try {
            this.playWithSarsa(this.cliffEnvironment, this.agent, thread);
        } catch (InterruptedException e) {
            System.out.println("Cliff walking thread stopped.");
        }
    }

    private void playWithSarsa(Environment environment, Agent agent, Thread thread) throws InterruptedException {
        State newState;
        while (true) {
            if (!CliffWalking.threadShutdown) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        epochsLabel.setText("Iterations: " + epochsCount.toString());
                    }
                });

        /**
         *  Main loop of algorithm, firstly moves by current action,
         *  Then newState is created and set as current
         *  Then algorithm checks if agent is not in any condition that results in end of episode
         *  These conditions are :
         *   1. Reaching the goal block
         *   2. Falling of the cliff
         *   3. Falling into the  water
         *  Every step is rewarded by different value
         *  After every step, new action is selected and replaces current action
         * */
                sarsaAgent.move(sarsaAgent.getCurrentAction()); // select next action

                newState = new State(agent.getX(), agent.getY()); // set new agent state
                sarsaAgent.setPreviousState(sarsaAgent.getCurrentState()); //set current state as previous state
                sarsaAgent.setCurrentState(newState); // set new current state
                if (environment.getGrid()[agent.getX()][agent.getY()].equals("-1") || environment.getGrid()[agent.getX()][agent.getY()].equals("*")) {
                    if (environment.getGrid()[agent.getX()][agent.getY()].equals("-1")) {
                        sarsaAgent.setReward(Constants.edgeFieldValue); // reward of out of the map
                    } else {
                        sarsaAgent.setReward(Constants.cliffFieldValue); // reward of out of the cliff
                    }
                    sarsaAgent.setPreviousAction(sarsaAgent.getCurrentAction());
                    sarsaAgent.setCurrentAction(sarsaAgent.getEpsilonGreedyUpdateSelection().selectAction(newState, sarsaAgent.getSarsa().getqTable()));
                    sarsaAgent.updateStrategy(); // update agent strategy after fail
                    restart(environment, sarsaAgent, agent);
                } else {
                    if (environment.getGrid()[agent.getX()][agent.getY()].equals("G")) {

//                        System.out.println("Iterations: " + epochsCount);

                        sarsaAgent.setReward(Constants.goalFieldValue); // reward of finish


                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                goalReachedLabel.setText("Goal reached!");
                            }
                        });

                        sarsaAgent.setPreviousAction(sarsaAgent.getCurrentAction());
                        sarsaAgent.setCurrentAction(sarsaAgent.getEpsilonGreedyUpdateSelection().selectAction(newState, sarsaAgent.getSarsa().getqTable()));
                        sarsaAgent.updateStrategy(); // update agent after success
                        restart(environment, sarsaAgent, agent);
                    } else {
                        if (environment.getGrid()[agent.getX()][agent.getY()].equals("S")) {
                            sarsaAgent.setReward(0.0); // reward of start
//                        sarsaAgent.setPreviousState(sarsaAgent.getqLearning().getqTable().getStateById(environment.getStartX() + "" + environment.getStartY()));
                        } else {
                            sarsaAgent.setReward(Constants.normalFieldValue); // reward of normal move
                        }
                        sarsaAgent.setPreviousAction(sarsaAgent.getCurrentAction());
                        sarsaAgent.setCurrentAction(sarsaAgent.getEpsilonGreedyUpdateSelection().selectAction(newState, sarsaAgent.getSarsa().getqTable()));
                        sarsaAgent.updateStrategy(); // update agent after normal move
                    }
                }


                if (normalSpeed) {
                    thread.sleep(100);
                } else {
                    accelerateEpochsCount++;
                    if (accelerateEpochsCount > 5000) {
                        normalSpeed = true;
                        accelerateEpochsCount = 0;
                    }
                }


            }
        }

    }


    /**
     * Init function for algorithm inits agent, initial current state and first action
     * */
    private void init() {

        controller = new Controller();


        // Init SARSA agent
        sarsaAgent = new SarsaAgent();
        sarsaAgent.setAgentArrowType(agent);

        State state = new State(agent.getX(), agent.getY());

        sarsaAgent.setCurrentState(state);
        sarsaAgent.setState(state);
        sarsaAgent.setCurrentAction(sarsaAgent.getEpsilonGreedyUpdateSelection().selectAction(sarsaAgent.getCurrentState(), sarsaAgent.getSarsa().getqTable()));
        sarsaAgent.setReward(0.0);

    }

    /**
     * Restart function for algorithm after falling of the cliff, walking into water or getting to reward block
     * */
    private void restart(Environment environment, SarsaAgent sarsaAgent, Agent agent) throws InterruptedException {
        agent.setPosition(environment.getStartX(), environment.getStartY());

        sarsaAgent.setPreviousState(sarsaAgent.getSarsa().getqTable().getStateById(environment.getStartX() + "" + environment.getStartY()));
        sarsaAgent.setCurrentState(sarsaAgent.getSarsa().getqTable().getStateById(environment.getStartX() + "" + environment.getStartY()));
        sarsaAgent.setCurrentAction(sarsaAgent.getEpsilonGreedyUpdateSelection().selectAction(sarsaAgent.getCurrentState(), sarsaAgent.getSarsa().getqTable()));
        sarsaAgent.setReward(0.0);

        epochsCount++;
//        Thread.sleep(1000);
    }
}
