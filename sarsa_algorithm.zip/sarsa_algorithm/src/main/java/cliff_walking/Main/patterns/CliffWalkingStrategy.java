package cliff_walking.Main.patterns;

import cliff_walking.Main.Environment;
import cliff_walking.Main.utils.Agent;

public interface CliffWalkingStrategy {
    void chooseTDAlgorithmAndExecute(Thread thread, Environment environment, Agent agent);
}
