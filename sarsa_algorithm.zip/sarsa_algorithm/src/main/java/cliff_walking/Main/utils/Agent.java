package cliff_walking.Main.utils;

import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.util.List;


public class Agent implements AgentArrowType {

    private int x;
    private int y;

    private int size = 40;

    private Color color;

    private Image robotImage = new Image("ReinforcementLearningAssets/CliffWalking/robot.png");
    private Image claptrapImage = new Image("ReinforcementLearningAssets/CliffWalking/claptrap.png");

    private Rectangle rectangle;

    private List<Integer>[][] gridPositions;


    public Agent() {
    }

    public Agent(int x, int y, int size, Color color, List<Integer>[][] gridPositions) {
        this.x = x;
        this.y = y;

        this.gridPositions = gridPositions;

        this.size = size;

        this.color = color;

        this.rectangle = new Rectangle(this.gridPositions[x][y].get(0), this.gridPositions[x][y].get(1), size, size);
        this.rectangle.setFill(color);
    }

    public Agent(int x, int y, int size, List<Integer>[][] gridPositions) {
        this.x = x;
        this.y = y;

        this.gridPositions = gridPositions;

        this.size = size;

        this.rectangle = new Rectangle(this.gridPositions[x][y].get(0), this.gridPositions[x][y].get(1), size, size);
        this.rectangle.setFill(new ImagePattern(this.robotImage));
//        this.rectangle.setFill(new ImagePattern(this.claptrapImage));
    }

    public void changeColor(Color color) {
        this.color = color;
        this.rectangle.setFill(color);
    }

    public void moveUp() {
//        this.rectangle.setTranslateX(this.gridPositions[x][y].get(1));
        this.x--;
        this.rectangle.setY(this.gridPositions[x][y].get(1));
    }

    public void moveDown() {
//        this.rectangle.setTranslateX(this.gridPositions[x][y].get(1));
        this.x++;
        this.rectangle.setY(this.gridPositions[x][y].get(1));
    }

    public void moveLeft() {
//        this.rectangle.setTranslateY(this.gridPositions[x][y].get(0));
        this.y--;
        this.rectangle.setX(this.gridPositions[x][y].get(0));
    }

    public void moveRight() {
//        this.rectangle.setTranslateY(this.gridPositions[x][y].get(0));
        this.y++;
        this.rectangle.setX(this.gridPositions[x][y].get(0));
    }


    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
        this.rectangle.setX(this.gridPositions[this.x][this.y].get(0));
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
        this.rectangle.setY(this.gridPositions[this.x][this.y].get(1));
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
        this.rectangle.setX(this.gridPositions[this.x][this.y].get(0));
        this.rectangle.setY(this.gridPositions[this.x][this.y].get(1));
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Rectangle getRectangle() {
        return rectangle;
    }

    public void setRectangle(Rectangle rectangle) {
        this.rectangle = rectangle;
    }

    public List<Integer>[][] getGridPositions() {
        return gridPositions;
    }

    public void setGridPositions(List<Integer>[][] gridPositions) {
        this.gridPositions = gridPositions;
    }
}