package cliff_walking.Main.utils;

public interface AgentArrowType {
    void moveUp();

    void moveDown();

    void moveLeft();

    void moveRight();
}
