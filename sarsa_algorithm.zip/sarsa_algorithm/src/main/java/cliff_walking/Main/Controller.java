package cliff_walking.Main;

import cliff_walking.Main.utils.Agent;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;


public class Controller {
    private static final int KEYBOARD_MOVEMENT_DELTA = 40;
    private static final Duration TRANSLATE_DURATION = Duration.seconds(0.3);

    public Controller() {

    }


    public void moveCircleOnKeyPress(Scene scene, Agent agent, TranslateTransition transition) {
        scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override public void handle(KeyEvent event) {
                switch (event.getCode()) {
                    case UP: {
                        agent.moveUp();
//                        playTransition(transition, agent.getRectangle());
                        break;
                    }
                    case RIGHT: {
                        agent.moveRight();
//                        playTransition(transition, agent.getRectangle());
                        break;
                    }
                    case DOWN: {
                        agent.moveDown();
//                        playTransition(transition, agent.getRectangle());
                        break;
                    }
                    case LEFT: {
                        agent.moveLeft();
//                        playTransition(transition, agent.getRectangle());
                        break;
                    }
                }
            }
        });
    }

    private void playTransition(TranslateTransition transition, Rectangle rect){
        transition.setToX(rect.getX());
        transition.setToY(rect.getY());
        transition.play();

    }

    public TranslateTransition createTranslateTransition(final Rectangle rect) {
        final TranslateTransition transition = new TranslateTransition(TRANSLATE_DURATION, rect);
        transition.setOnFinished(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent t) {
                rect.setTranslateX(rect.getX());
                rect.setTranslateY(rect.getY());

            }
        });
        return transition;
    }
}
