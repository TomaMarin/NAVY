package TD_Algorithms.models;

import java.util.HashMap;
import java.util.Map;


public class Q_table {

    private Map<State, Q_row> qTable;

    public Q_table() {
        this.qTable = new HashMap<>();
    }

    public Q_row getQValueAtRow(State state){
        Q_row q_row;

        if(this.qTable.containsKey(state)){
            q_row = this.qTable.get(state);
        } else {
            q_row = new Q_row();
            qTable.put(state, q_row);
        }
        return q_row;
    }

    public void addNewState(State state){
        Q_row q_row = new Q_row();
        qTable.put(state, q_row);
    }

    public void addQvalueAtRow(State state, Double QValue) {
        this.qTable.get(state).setQValue(QValue);
    }

    public Action getActionOfMaxQ(State state){
        if (this.qTable.containsKey(state)){
            return this.qTable.get(state).getBiggestQValue();
        } else {
            qTable.put(state, new Q_row());
            return this.qTable.get(state).getBiggestQValue();
        }
    }

    public Action getRandomActionFromQ(State state){
        if (this.qTable.containsKey(state)){
            return this.qTable.get(state).getRandomQValue();
        } else {
            qTable.put(state, new Q_row());
            return this.qTable.get(state).getRandomQValue();
        }
    }

    public void setSpecificActionValueToState(State state, Action action) {
        this.qTable.get(state).getQ_actions().stream().filter(a -> a.getType().equals(action.getType())).findAny().get().setValue(action.getValue());
    }

    public State getStateById(String stateId) {
        return this.qTable.keySet().stream().filter(f -> f.getId().equals(stateId)).findAny().get();
    }

    public void reset(){
        this.qTable.clear();
    }

}
