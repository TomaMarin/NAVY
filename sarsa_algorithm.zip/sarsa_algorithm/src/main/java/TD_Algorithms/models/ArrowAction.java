package TD_Algorithms.models;

public enum ArrowAction {
    NONE, UP, DOWN, LEFT, RIGHT
}
