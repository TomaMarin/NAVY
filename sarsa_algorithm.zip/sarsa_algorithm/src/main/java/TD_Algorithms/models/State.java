package TD_Algorithms.models;

public class State {

    private String id;

    private Integer x;

    private Integer y;

    public State() {
    }

    public State(String id) {
        this.id = id;
        this.x = 0;
        this.y = 0;
    }

    public State(Integer x, Integer y) {
        this.id = x.toString() + y.toString();
        this.x = x;
        this.y = y;
    }

    public State(String id, Integer x, Integer y) {
        this.id = id;
        this.x = x;
        this.y = y;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        State state = (State) o;

        if (id != null ? !id.equals(state.id) : state.id != null) return false;
        if (x != null ? !x.equals(state.x) : state.x != null) return false;
        return y != null ? y.equals(state.y) : state.y == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (x != null ? x.hashCode() : 0);
        result = 31 * result + (y != null ? y.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "State{" +
                "id='" + id + '\'' +
                '}';
    }
}
