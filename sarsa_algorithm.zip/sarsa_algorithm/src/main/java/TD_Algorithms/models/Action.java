package TD_Algorithms.models;



public class Action {

    private ArrowAction type;

    private Double value;

    public Action() {
    }

    public Action(Double value) {
        this.type = ArrowAction.NONE;
        this.value = value;
    }

    public Action(ArrowAction arrowAction) {
        this.type = arrowAction;
        this.value = 0.0;
    }

    public Action(ArrowAction type, Double value) {
        this.type = type;
        this.value = value;
    }

    public ArrowAction getType() {
        return type;
    }

    public void setType(ArrowAction type) {
        this.type = type;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Action action = (Action) o;

        if (type != action.type) return false;
        return value != null ? value.equals(action.value) : action.value == null;
    }

    @Override
    public int hashCode() {
        int result = type != null ? type.hashCode() : 0;
        result = 31 * result + (value != null ? value.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Action{" +
                "type=" + type +
                ", value=" + value +
                '}';
    }
}
