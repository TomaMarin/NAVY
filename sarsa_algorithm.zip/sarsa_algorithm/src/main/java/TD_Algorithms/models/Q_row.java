package TD_Algorithms.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class Q_row {

    private Random generator = new Random();

    private List<Action> Q_actions = new ArrayList<>();

    private Double QValue = 0.0;

    public Q_row(){
        for(int i = 1; i < ArrowAction.values().length; i++){
            this.Q_actions.add(new Action(ArrowAction.values()[i], 0.0));
        }
    }

    public Double getQValue() {
        return QValue;
    }

    public void setQValue(Double QValue) {
        this.QValue = QValue;
    }

    public void setActionValue(ArrowAction arrowAction, Double value){
        this.Q_actions.stream().filter(a -> a.getType().equals(arrowAction)).findAny().get().setValue(value);
    }

    public Action getBiggestQValue(){
        Action action = this.Q_actions.stream().max((q1,q2) -> q1.getValue().compareTo(q2.getValue())).get();

        return action;
    }

    public Action getRandomQValue(){
        Object[] actions = this.Q_actions.toArray();
        Action randomAction = (Action) actions[generator.nextInt(actions.length)];

        return randomAction;
    }

    public List<Action> getQ_actions() {
        return Q_actions;
    }

    public void setQ_actions(List<Action> q_actions) {
        Q_actions = q_actions;
    }
}
