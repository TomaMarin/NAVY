package TD_Algorithms.utils;

public class Constants {

    // Q-learning
    public static Double gamma = 0.9;
    public static Double alpha = 0.4;
    public static Double omicron = 0.4;
    public static Double lambda = 0.9;

    // Policy
    public static Double epsilon = 0.2;

    // Cliff walking field values
    public static Double  normalFieldValue = -1.0;
    public static Double goalFieldValue = 200.0;
    public static Double  cliffFieldValue = -150.0;
    public static Double edgeFieldValue = -150.0;
    public static void setToDefaultValues() {
        gamma = 0.9;
        alpha = 0.4;
        epsilon = 0.2;
        normalFieldValue = 1.0;
        goalFieldValue = 500.0;
        cliffFieldValue = -500.0;
        edgeFieldValue = -100.0;
    }
    // Recommended settings for SARSA algorithm
    public static void setToDefaultValuesForSarsa() {

        gamma = 0.95;
        alpha = 0.4;
        epsilon = 0.1;
        normalFieldValue = -1.0;
        goalFieldValue = 100.0;
        cliffFieldValue = -100.0;
        edgeFieldValue = -100.0;
        omicron = 0.7;
        lambda = 0.9;
    }
}
