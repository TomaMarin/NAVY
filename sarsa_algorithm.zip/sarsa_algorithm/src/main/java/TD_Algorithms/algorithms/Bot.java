package TD_Algorithms.algorithms;



import TD_Algorithms.models.Action;
import TD_Algorithms.models.State;
import cliff_walking.Main.utils.AgentArrowType;

import java.util.ArrayList;
import java.util.List;

public abstract class Bot {

    protected State currentState;

    protected State previousState;

    protected Action currentAction;

    protected Double reward = 0.0;


    protected AgentArrowType agentArrowType;


    protected List<Move> moves = new ArrayList<>();


    public abstract Action selectActionAndAct(State state);

    public abstract void updateStrategy();


    public Bot() {
    }

    public Bot(AgentArrowType agentArrowType) {
        this.agentArrowType = agentArrowType;
    }


    public AgentArrowType getAgentArrowType() {
        return agentArrowType;
    }

    public void setAgentArrowType(AgentArrowType agentArrowType) {
        this.agentArrowType = agentArrowType;
    }

    public void addMove(Move move){
        this.moves.add(move);
    }

    public List<Move> getMoves() {
        return moves;
    }

    public void setMoves(List<Move> moves) {
        this.moves = moves;
    }

    public State getCurrentState() {
        return currentState;
    }

    public void setCurrentState(State currentState) {
        this.currentState = currentState;
    }

    public State getPreviousState() {
        return previousState;
    }

    public void setPreviousState(State previousState) {
        this.previousState = previousState;
    }

    public Action getCurrentAction() {
        return currentAction;
    }

    public void setCurrentAction(Action currentAction) {
        this.currentAction = currentAction;
    }

    public Double getReward() {
        return reward;
    }

    public void setReward(Double reward) {
        this.reward = reward;
    }
}
