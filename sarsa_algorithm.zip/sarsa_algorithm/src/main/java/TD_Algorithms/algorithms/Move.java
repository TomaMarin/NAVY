package TD_Algorithms.algorithms;


import TD_Algorithms.models.Action;
import TD_Algorithms.models.State;

public class Move {

    private State oldState;

    private State currentState;

    private Action action;

    private Double reward;

    public Move() {
    }

    public Move(State oldState, State currentState, Action action, Double reward) {
        this.oldState = oldState;
        this.currentState = currentState;
        this.action = action;
        this.reward = reward;
    }

    public State getOldState() {
        return oldState;
    }

    public void setOldState(State oldState) {
        this.oldState = oldState;
    }

    public State getCurrentState() {
        return currentState;
    }

    public void setCurrentState(State currentState) {
        this.currentState = currentState;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public Double getReward() {
        return reward;
    }

    public void setReward(Double reward) {
        this.reward = reward;
    }


    @Override
    public String toString() {
        return "Move{" +
                "oldState=" + oldState +
                ", currentState=" + currentState +
                ", action=" + action +
                ", reward=" + reward +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Move move = (Move) o;

        if (oldState != null ? !oldState.equals(move.oldState) : move.oldState != null) return false;
        if (currentState != null ? !currentState.equals(move.currentState) : move.currentState != null) return false;
        if (action != null ? !action.equals(move.action) : move.action != null) return false;
        return reward != null ? reward.equals(move.reward) : move.reward == null;
    }

    @Override
    public int hashCode() {
        int result = oldState != null ? oldState.hashCode() : 0;
        result = 31 * result + (currentState != null ? currentState.hashCode() : 0);
        result = 31 * result + (action != null ? action.hashCode() : 0);
        result = 31 * result + (reward != null ? reward.hashCode() : 0);
        return result;
    }
}
