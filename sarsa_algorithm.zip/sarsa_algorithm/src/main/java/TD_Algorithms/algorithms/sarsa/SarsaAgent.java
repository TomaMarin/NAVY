package TD_Algorithms.algorithms.sarsa;

import TD_Algorithms.algorithms.Bot;
import TD_Algorithms.models.Action;
import TD_Algorithms.models.State;
import TD_Algorithms.updateFunctions.EpsilonGreedyUpdateSelection;

public class SarsaAgent extends Bot {

    private Sarsa sarsa;
    private EpsilonGreedyUpdateSelection epsilonGreedyUpdateSelection;

    public Action getPreviousAction() {
        return previousAction;
    }

    public void setPreviousAction(Action previousAction) {
        this.previousAction = previousAction;
    }

    private Action previousAction;

    public SarsaAgent() {
        super();
        this.sarsa = new Sarsa();
        this.epsilonGreedyUpdateSelection = new EpsilonGreedyUpdateSelection();
    }


    /**
     * Method of agent for SARSA algorithm, where agent moves by new action of  state
     * */
    public void  move(Action action){

        switch (action.getType()) {
            case UP: {
                this.agentArrowType.moveUp();
                break;
            }
            case DOWN: {
                this.agentArrowType.moveDown();
                break;
            }
            case LEFT: {
                this.agentArrowType.moveLeft();
                break;
            }
            case RIGHT: {
                this.agentArrowType.moveRight();
                break;
            }
            default: {
            }

        }
    }

    @Override
    public Action selectActionAndAct(State state) {
        if (state == null) {
            throw new IllegalArgumentException("Object of " + State.class + " was not found");
        } else {
            Action chosenAction = epsilonGreedyUpdateSelection.selectAction(state, sarsa.getqTable());

            switch (chosenAction.getType()) {
                case UP: {
                    this.agentArrowType.moveUp();
                    break;
                }
                case DOWN: {
                    this.agentArrowType.moveDown();
                    break;
                }
                case LEFT: {
                    this.agentArrowType.moveLeft();
                    break;
                }
                case RIGHT: {
                    this.agentArrowType.moveRight();
                    break;
                }
                default: {
                }

            }

            return chosenAction;
        }
    }


    @Override
    public void updateStrategy() {
        sarsa.update(this.getPreviousState(), this.getPreviousAction(),this.getCurrentAction(), this.getCurrentState(), this.getReward());
    }

    public void setState(State state) {
        this.sarsa.getqTable().addNewState(state);
    }

    public Sarsa getSarsa() {
        return sarsa;
    }

    public void setSarsa(Sarsa sarsa) {
        this.sarsa = sarsa;
    }

    public EpsilonGreedyUpdateSelection getEpsilonGreedyUpdateSelection() {
        return epsilonGreedyUpdateSelection;
    }

    public void setEpsilonGreedyUpdateSelection(EpsilonGreedyUpdateSelection epsilonGreedyUpdateSelection) {
        this.epsilonGreedyUpdateSelection = epsilonGreedyUpdateSelection;
    }

    public void reset() {
        this.sarsa.resetQTable();
    }
}
