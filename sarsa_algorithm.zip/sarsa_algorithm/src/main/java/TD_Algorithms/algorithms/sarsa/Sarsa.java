package TD_Algorithms.algorithms.sarsa;

import TD_Algorithms.models.Action;
import TD_Algorithms.models.Q_table;
import TD_Algorithms.models.State;
import TD_Algorithms.updateFunctions.EpsilonGreedyUpdateSelection;
import TD_Algorithms.utils.Constants;

public class Sarsa {
    Q_table q_table;
    EpsilonGreedyUpdateSelection epsilonGreedyUpdateSelection;

    public Sarsa() {
        this.q_table = new Q_table();
        epsilonGreedyUpdateSelection = new EpsilonGreedyUpdateSelection();
    }


    /**
     * Update method of Q_table for SARSA algorithm, in comparison with Q-Learning it also requires newAction,
     * that is given by newState
     * This newAction is based on epsilon-greedy policy not by action with max Q_table value
     *
     * There is also implementation of Q-SARSA, that is of course the mixture of Q-Learning and SARSA
     * By constant omicron we can handle the weight of Q-Learning action pick as well as SARSA action pick
     */
    public void update(State oldState, Action action, Action newAction, State newState, double reward) {
//        Q_table value of old state and its action
        Double oldQ = q_table.getQValueAtRow(oldState).getQValue();


        Double newActionValue = newAction.getValue();
//        MAX Q_table value for Q-SARSA algorithm
//        Double maxQ = q_table.getActionOfMaxQ(newState).getValue();
        // ONE-STEP SARSA bellman equation
        Double newQ = oldQ + Constants.alpha * (reward + Constants.gamma * newActionValue - oldQ);

        // ONE-STEP Q-SARSA bellman equation
//        Double newQ = oldQ + Constants.alpha * (reward + Constants.gamma *( (1-Constants.omicron) * maxQ + Constants.omicron*newActionValue)-oldQ );

//      Set value to Q table to current new state of agent
        this.q_table.addQvalueAtRow(newState, newQ);

        action.setValue(newQ);
//      Set value to Q table to specific action taken in previous state
        this.q_table.setSpecificActionValueToState(oldState, action);
    }

    public Q_table getqTable() {
        return this.q_table;
    }

    public void setqTable(Q_table qTable) {
        this.q_table = qTable;
    }

    public void resetQTable() {
        this.q_table.reset();
    }

}
