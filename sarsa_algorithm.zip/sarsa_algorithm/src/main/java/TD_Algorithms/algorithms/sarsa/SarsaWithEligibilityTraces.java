//package TD_Algorithms.algorithms.sarsa;
//
//import reinforcementLearning.TD_Algorithms.models.Action;
//import reinforcementLearning.TD_Algorithms.models.Q_row;
//import reinforcementLearning.TD_Algorithms.models.Q_table;
//import reinforcementLearning.TD_Algorithms.models.State;
//import reinforcementLearning.TD_Algorithms.updateFunctions.EpsilonGreedyUpdateSelection;
//import reinforcementLearning.TD_Algorithms.utils.Constants;
//
//import java.util.Map;
//
//public class SarsaWithEligibilityTraces {
//    Q_table q_table;
//    Map<State, Q_row> e_Table;
//
//    public SarsaWithEligibilityTraces(Q_table q_table, Map<State, Q_row> e_Table, EpsilonGreedyUpdateSelection epsilonGreedyUpdateSelection) {
//        this.q_table = q_table;
//        this.e_Table = e_Table;
//        this.epsilonGreedyUpdateSelection = epsilonGreedyUpdateSelection;
//    }
//
//    EpsilonGreedyUpdateSelection epsilonGreedyUpdateSelection;
//
//    public SarsaWithEligibilityTraces() {
//        this.q_table = new Q_table();
//        epsilonGreedyUpdateSelection = new EpsilonGreedyUpdateSelection();
//    }
//
//    public void update(State oldState, Action action, State newState, double reward) {
//        Double oldQ = q_table.getQValueAtRow(oldState).getQValue();
//
//        Double epsilonNextAction = epsilonGreedyUpdateSelection.selectAction(newState, q_table).getValue();
//        Double maxQ = q_table.getActionOfMaxQ(newState).getValue();
//
//        Double newDelta = Constants.alpha * (reward + Constants.gamma * ((1 - Constants.omicron) * maxQ + Constants.omicron * epsilonNextAction) - oldQ);
//        setSpecificActionValueToState(oldState, action,1.0);
//
//        this.q_table.addQvalueAtRow(newState, newDelta); // Set value to Q table to current new state of agent
//
//        action.setValue(newDelta);
//
//        this.q_table.setSpecificActionValueToState(oldState, action); // Set value to Q table to specific action taken in previous state
//    }
//
//    public Q_table getqTable() {
//        return this.q_table;
//    }
//
//    public void setqTable(Q_table qTable) {
//        this.q_table = qTable;
//    }
//
//    public void resetQTable() {
//        this.q_table.reset();
//    }
//
//    public Map<State, Q_row> getE_Table() {
//        return e_Table;
//    }
//
//    public void setE_Table(Map<State, Q_row> e_Table) {
//        this.e_Table = e_Table;
//    }
//
//    public void setSpecificActionValueToState(State state, Action action, Double value) {
//        Action newAction = action;
//        newAction.setValue(value);
//        this.e_Table.get(state).getQ_actions().stream().filter(a -> a.getType().equals(newAction.getType())).findAny().get().setValue(newAction.getValue());
//    }
//   public void setSpecificActionsValueToState(State state, Double value) {
//        this.e_Table.get(state).getQ_actions().forEach(action -> action.setValue(value));
//    }
//
//
//}
