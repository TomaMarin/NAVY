package TD_Algorithms.updateFunctions;


import TD_Algorithms.models.Action;
import TD_Algorithms.models.Q_table;
import TD_Algorithms.models.State;
import TD_Algorithms.utils.Constants;

import java.util.Random;


public class EpsilonGreedyUpdateSelection {

    private Random random = new Random();

//    private Double epsilon = 0.2;

    /**
     * Epsilon greedy policy for action select, this method is used for init action  as well as for next action,
     * If random number is lower than Epsilon it selects random action, otherwise action with biggest q_value is selected
     * */
    public Action selectAction(State state, Q_table q_table){
        if(state==null){
            throw new IllegalArgumentException("Object of " +State.class+ " was not found");
        }
        else {
            if (random.nextDouble() < Constants.epsilon) {
                return q_table.getRandomActionFromQ(state);
            } else {
                return q_table.getActionOfMaxQ(state);
            }
        }
    }

//    public Double getEpsilon() {
//        return epsilon;
//    }
//
//    public void setEpsilon(Double epsilon) {
//        this.epsilon = epsilon;
//    }
}