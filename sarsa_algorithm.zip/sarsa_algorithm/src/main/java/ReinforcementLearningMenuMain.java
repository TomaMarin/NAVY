import cliff_walking.CliffWalkingMenu;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ReinforcementLearningMenuMain extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        // SnakeMenu pane
        BorderPane mainPane = new BorderPane();


        // Header pane
        VBox headerVbox = new VBox();

        Text headline = new Text("Reinforcement learning playground");
        headline.setFont(new Font("Arial Black", 36));
        headline.setFill(Color.WHITE);

        headerVbox.setAlignment(Pos.CENTER);
        headerVbox.setBackground(new Background(new BackgroundFill(Color.DARKSLATEGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        headerVbox.getChildren().add(headline);


        // Content pane
        TilePane contentTilePane = new TilePane();
        contentTilePane.setHgap(20.0);
        contentTilePane.setVgap(20.0);
        contentTilePane.setPadding(new Insets(20,20,20,20));

        //Cliff walking
        Button cliffButton = new Button();
        cliffButton.getStyleClass().add("cliff-walking-button");
        cliffButton.setPrefSize(150.0,150.0);
        cliffButton.setOnAction(event -> {
            new CliffWalkingMenu();
        });


        contentTilePane.getChildren().add(cliffButton);

        mainPane.setTop(headerVbox);
        mainPane.setCenter(contentTilePane);

        Scene scene = new Scene(mainPane,800,500);
        scene.getStylesheets().add("css/MainMenuStyles.css");

        primaryStage.setScene(scene);
        primaryStage.setTitle("Reinforcement learning playground");
        primaryStage.show();
    }
}
